
  # API Showcase Dashboard UI

  This is a code bundle for API Showcase Dashboard UI. The original project is available at https://www.figma.com/design/eVS85daACDEcQo99cXiCK9/API-Showcase-Dashboard-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  